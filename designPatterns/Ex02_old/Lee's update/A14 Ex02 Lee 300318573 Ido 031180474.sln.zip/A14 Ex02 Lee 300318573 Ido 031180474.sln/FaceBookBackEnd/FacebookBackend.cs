﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FacebookWrapper.ObjectModel;
using FacebookWrapper;


namespace FaceBookBackEnd
{
    public class FacebookBackend : IAuthenticator
    {
        private User m_LoggedInUser;
        private readonly string APP_ID = "556910297710526";

        public User LogIn()
        {
            if (m_LoggedInUser == null)
            {
                LoginResult result = FacebookService.Login(APP_ID,
                        "user_about_me", "friends_about_me", "publish_stream", "user_events", "read_stream",
                        "user_status", "friends_checkins");
                if (string.IsNullOrEmpty(result.ErrorMessage))
                {   
                    m_LoggedInUser = result.LoggedInUser;
                }
                else
                {
                    throw new Exception(result.ErrorMessage);
                }
            }
            return m_LoggedInUser;
        }
    }
}
