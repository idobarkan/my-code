﻿// -----------------------------------------------------------------------
// <copyright file="FacebookCheckInVicinityProvider.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace FindTagsAround
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
using FacebookWrapper.ObjectModel;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class FacebookCheckInVicinityProvider : ICheckInVicinityProvider
    {
        public Dictionary<string, Checkin> getAllUserFriendsRecentTags(User i_LoggedInUser, DateTime i_Oldest)
        {
            var recentFriendsTags = new Dictionary<string, Checkin>();
            foreach (var friend in i_LoggedInUser.Friends)
            {
                foreach (var checkIn in friend.Checkins)
                {
                    if (checkIn.CreatedTime > i_Oldest)
                    {
                        recentFriendsTags[checkIn.Id] = checkIn;
                    }
                }
            }
            return recentFriendsTags;
        }
    }
}
